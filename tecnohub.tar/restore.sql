--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE tecnohub;
--
-- Name: tecnohub; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE tecnohub WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE tecnohub OWNER TO postgres;

\connect tecnohub

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categoria (
    cat_cd_id integer NOT NULL,
    cat_tx_nome character varying(45) NOT NULL,
    cat_tx_descricao text NOT NULL
);


ALTER TABLE public.categoria OWNER TO postgres;

--
-- Name: categoria_cat_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categoria_cat_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categoria_cat_id_seq OWNER TO postgres;

--
-- Name: categoria_cat_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categoria_cat_id_seq OWNED BY public.categoria.cat_cd_id;


--
-- Name: endereco; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.endereco (
    end_cd_id integer NOT NULL,
    end_tx_rua character varying(45) NOT NULL,
    end_tx_bairro character varying(45) NOT NULL,
    end_tx_numero character varying(10) NOT NULL,
    end_tx_cidade character varying(45) NOT NULL,
    end_tx_estado character varying(45) NOT NULL
);


ALTER TABLE public.endereco OWNER TO postgres;

--
-- Name: endereco_end_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.endereco_end_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.endereco_end_id_seq OWNER TO postgres;

--
-- Name: endereco_end_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.endereco_end_id_seq OWNED BY public.endereco.end_cd_id;


--
-- Name: funcionario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.funcionario (
    func_cd_id integer NOT NULL,
    func_tx_nome character varying(45) NOT NULL,
    func_tx_cpf character varying(11) NOT NULL
);


ALTER TABLE public.funcionario OWNER TO postgres;

--
-- Name: funcionario_func_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.funcionario_func_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.funcionario_func_id_seq OWNER TO postgres;

--
-- Name: funcionario_func_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.funcionario_func_id_seq OWNED BY public.funcionario.func_cd_id;


--
-- Name: pedido; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido (
    ped_cd_id integer NOT NULL,
    ped_dt_data_pedido timestamp without time zone NOT NULL,
    usu_int_id integer
);


ALTER TABLE public.pedido OWNER TO postgres;

--
-- Name: pedido_produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido_produto (
    pedpro_cd_id integer NOT NULL,
    prod_int_id integer,
    ped_int_id integer
);


ALTER TABLE public.pedido_produto OWNER TO postgres;

--
-- Name: produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produto (
    prod_cd_id integer NOT NULL,
    prod_tx_nome character varying(45) NOT NULL,
    prod_tx_descricao text NOT NULL,
    prod_int_estoque integer NOT NULL,
    prod_dt_data_fabricacao date NOT NULL,
    prod_nm_valor double precision NOT NULL,
    cat_int_id integer,
    func_int_id integer
);


ALTER TABLE public.produto OWNER TO postgres;

--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario (
    usu_cd_id integer NOT NULL,
    usu_tx_nome character varying(45) NOT NULL,
    usu_tx_nome_usuario character varying(45) NOT NULL,
    usu_tx_email character varying(45) NOT NULL,
    usu_tx_cpf character varying(11) NOT NULL,
    usu_dt_data_nascimento date NOT NULL,
    end_int_id integer NOT NULL
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- Name: nota_fiscal; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.nota_fiscal AS
 SELECT u.usu_tx_nome,
    u.usu_tx_cpf,
    p.ped_dt_data_pedido,
    p2.prod_tx_nome,
    p2.prod_nm_valor,
    f.func_tx_nome
   FROM ((((public.usuario u
     JOIN public.pedido p ON ((u.usu_cd_id = p.usu_int_id)))
     JOIN public.pedido_produto pp ON ((p.ped_cd_id = pp.ped_int_id)))
     JOIN public.produto p2 ON ((pp.prod_int_id = p2.prod_cd_id)))
     JOIN public.funcionario f ON ((p2.func_int_id = f.func_cd_id)));


ALTER TABLE public.nota_fiscal OWNER TO postgres;

--
-- Name: pedido_ped_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedido_ped_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedido_ped_id_seq OWNER TO postgres;

--
-- Name: pedido_ped_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pedido_ped_id_seq OWNED BY public.pedido.ped_cd_id;


--
-- Name: pedido_produto_pedpro_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedido_produto_pedpro_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedido_produto_pedpro_id_seq OWNER TO postgres;

--
-- Name: pedido_produto_pedpro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pedido_produto_pedpro_id_seq OWNED BY public.pedido_produto.pedpro_cd_id;


--
-- Name: produto_prod_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produto_prod_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_prod_id_seq OWNER TO postgres;

--
-- Name: produto_prod_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produto_prod_id_seq OWNED BY public.produto.prod_cd_id;


--
-- Name: usuario_usu_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuario_usu_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuario_usu_id_seq OWNER TO postgres;

--
-- Name: usuario_usu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuario_usu_id_seq OWNED BY public.usuario.usu_cd_id;


--
-- Name: categoria cat_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria ALTER COLUMN cat_cd_id SET DEFAULT nextval('public.categoria_cat_id_seq'::regclass);


--
-- Name: endereco end_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco ALTER COLUMN end_cd_id SET DEFAULT nextval('public.endereco_end_id_seq'::regclass);


--
-- Name: funcionario func_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario ALTER COLUMN func_cd_id SET DEFAULT nextval('public.funcionario_func_id_seq'::regclass);


--
-- Name: pedido ped_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido ALTER COLUMN ped_cd_id SET DEFAULT nextval('public.pedido_ped_id_seq'::regclass);


--
-- Name: pedido_produto pedpro_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_produto ALTER COLUMN pedpro_cd_id SET DEFAULT nextval('public.pedido_produto_pedpro_id_seq'::regclass);


--
-- Name: produto prod_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto ALTER COLUMN prod_cd_id SET DEFAULT nextval('public.produto_prod_id_seq'::regclass);


--
-- Name: usuario usu_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario ALTER COLUMN usu_cd_id SET DEFAULT nextval('public.usuario_usu_id_seq'::regclass);


--
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3386.dat

--
-- Data for Name: endereco; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3388.dat

--
-- Data for Name: funcionario; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3390.dat

--
-- Data for Name: pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3392.dat

--
-- Data for Name: pedido_produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3394.dat

--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3396.dat

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3398.dat

--
-- Name: categoria_cat_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categoria_cat_id_seq', 10, true);


--
-- Name: endereco_end_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.endereco_end_id_seq', 10, true);


--
-- Name: funcionario_func_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.funcionario_func_id_seq', 5, true);


--
-- Name: pedido_ped_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedido_ped_id_seq', 15, true);


--
-- Name: pedido_produto_pedpro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedido_produto_pedpro_id_seq', 10, true);


--
-- Name: produto_prod_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produto_prod_id_seq', 10, true);


--
-- Name: usuario_usu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuario_usu_id_seq', 10, true);


--
-- Name: categoria categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (cat_cd_id);


--
-- Name: endereco endereco_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco
    ADD CONSTRAINT endereco_pkey PRIMARY KEY (end_cd_id);


--
-- Name: funcionario funcionario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_pkey PRIMARY KEY (func_cd_id);


--
-- Name: pedido pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_pkey PRIMARY KEY (ped_cd_id);


--
-- Name: pedido_produto pedido_produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_produto
    ADD CONSTRAINT pedido_produto_pkey PRIMARY KEY (pedpro_cd_id);


--
-- Name: produto produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (prod_cd_id);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (usu_cd_id);


--
-- Name: usuario usuario_usu_cpf_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_usu_cpf_key UNIQUE (usu_tx_cpf);


--
-- Name: usuario usuario_usu_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_usu_email_key UNIQUE (usu_tx_email);


--
-- Name: ped1_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ped1_index ON public.pedido USING btree (ped_cd_id, ped_dt_data_pedido, usu_int_id);


--
-- Name: prod1_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX prod1_index ON public.produto USING btree (prod_tx_nome, prod_int_estoque, prod_cd_id);


--
-- Name: prod2_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX prod2_index ON public.produto USING btree (prod_nm_valor, prod_dt_data_fabricacao);


--
-- Name: usu1_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX usu1_index ON public.usuario USING btree (usu_cd_id, usu_tx_nome, usu_tx_cpf, usu_dt_data_nascimento);


--
-- Name: usu2_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX usu2_index ON public.usuario USING btree (usu_tx_nome_usuario, usu_tx_email, end_int_id);


--
-- Name: pedido_produto pedido_produto_ped_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_produto
    ADD CONSTRAINT pedido_produto_ped_id_fkey FOREIGN KEY (ped_int_id) REFERENCES public.pedido(ped_cd_id);


--
-- Name: pedido_produto pedido_produto_prod_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido_produto
    ADD CONSTRAINT pedido_produto_prod_id_fkey FOREIGN KEY (prod_int_id) REFERENCES public.produto(prod_cd_id);


--
-- Name: pedido pedido_usu_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_usu_id_fkey FOREIGN KEY (usu_int_id) REFERENCES public.usuario(usu_cd_id);


--
-- Name: produto produto_cat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_cat_id_fkey FOREIGN KEY (cat_int_id) REFERENCES public.categoria(cat_cd_id);


--
-- Name: produto produto_func_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_func_id_fkey FOREIGN KEY (func_int_id) REFERENCES public.funcionario(func_cd_id);


--
-- Name: usuario usuario_end_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_end_id_fkey FOREIGN KEY (end_int_id) REFERENCES public.endereco(end_cd_id);


--
-- Name: DATABASE tecnohub; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE tecnohub TO administrator;


--
-- Name: TABLE categoria; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.categoria TO empregado;


--
-- Name: TABLE funcionario; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,UPDATE ON TABLE public.funcionario TO empregado;


--
-- Name: TABLE pedido; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pedido TO cliente;


--
-- Name: TABLE pedido_produto; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pedido_produto TO cliente;


--
-- Name: TABLE produto; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,REFERENCES,UPDATE ON TABLE public.produto TO empregado;
GRANT SELECT ON TABLE public.produto TO cliente;


--
-- Name: TABLE usuario; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.usuario TO administrator;
GRANT DELETE ON TABLE public.usuario TO cliente;


--
-- Name: COLUMN usuario.usu_tx_nome; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(usu_tx_nome),UPDATE(usu_tx_nome) ON TABLE public.usuario TO cliente;


--
-- Name: COLUMN usuario.usu_tx_nome_usuario; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(usu_tx_nome_usuario),UPDATE(usu_tx_nome_usuario) ON TABLE public.usuario TO cliente;


--
-- Name: COLUMN usuario.usu_tx_email; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(usu_tx_email),UPDATE(usu_tx_email) ON TABLE public.usuario TO cliente;


--
-- Name: COLUMN usuario.usu_tx_cpf; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT(usu_tx_cpf),UPDATE(usu_tx_cpf) ON TABLE public.usuario TO cliente;


--
-- Name: TABLE nota_fiscal; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.nota_fiscal TO empregado;
GRANT SELECT ON TABLE public.nota_fiscal TO cliente;


--
-- PostgreSQL database dump complete
--

